import 'package:firebase_auth/firebase_auth.dart';

abstract class BaseAuth {
  Future<String> inputData();
}

class User {
  @override
  Future<String> inputData() async {
    final FirebaseUser user = await FirebaseAuth.instance.currentUser();
    final String uid = user.uid.toString();
    return uid;
  }
}
