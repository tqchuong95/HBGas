class Products {
  var products = [
    {
      'name': 'Bình gas vàng',
      'image': 'images/products/gas-vang-lon.jpg',
      'oldPrice': 320000,
      'price': 280000,
      'prodDesc':
          "Bình gas 12kg - Màu vàng - Van vặn - Sản phẩm chất lượng của Cty TNHH TM Gas Bình Minh",
    },
    {
      'name': 'Bình gas xanh',
      'image': 'images/products/binh-minh-xanh-lon.jpg',
      'oldPrice': 380000,
      'price': 350000,
      'prodDesc':
          "Bình gas 12kg - Màu xanh - Van tự động - Sản phẩm chất lượng của Cty TNHH TM Gas Bình Minh",
    },
    {
      'name': 'Bình gas gia đình đỏ',
      'image': 'images/products/gd-do-lon.jpg',
      'oldPrice': 280000,
      'price': 250000,
      'prodDesc':
          "Bình gas 12kg - Màu đỏ - Sản phẩm của Công ty TNHH MTV Khí Đốt Gia Đình - Thành viên của Tập đoàn ANPHA PETRO",
    },
    {
      'name': 'Bình gas gia đình xám',
      'image': 'images/products/gd-xam-lon.jpg',
      'oldPrice': 420000,
      'price': 370000,
      'prodDesc':
          "Bình gas 12kg - Màu xám - Sản phẩm của Công ty TNHH MTV Khí Đốt Gia Đình - Thành viên của Tập đoàn ANPHA PETRO",
    },
    {
      'name': 'Bình gas gia đình xanh đậm',
      'image': 'images/products/gd-xanh-lon.jpg',
      'oldPrice': 540000,
      'price': 480000,
      'prodDesc':
          "Bình gas 12kg - Màu xanh đậm - Sản phẩm của Công ty TNHH MTV Khí Đốt Gia Đình - Thành viên của Tập đoàn ANPHA PETRO",
    },
    {
      'name': 'Bình gas gia đình vàng',
      'image': 'images/products/gd-vang-lon.jpg',
      'oldPrice': 620000,
      'price': 580000,
      'prodDesc':
          "Bình gas 12kg - Màu vàng - Sản phẩm của Công ty TNHH MTV Khí Đốt Gia Đình - Thành viên của Tập đoàn ANPHA PETRO",
    },
    {
      'name': 'Bình gas công nghiệp',
      'image': 'images/products/tap-hop-cac-binh-gass-lon.png',
      'oldPrice': 1500000,
      'price': 1350000,
      'prodDesc':
          "Bình gas 45kg - Màu xanh - Sản phẩm của Cty Shell Gas",
    },
    {
      'name': 'Bình gas công nghiệp vàng',
      'image': 'images/products/binh-minh-gas-lon.jpg',
      'oldPrice': 2500000,
      'price': 2300000,
      'prodDesc':
          "Bình gas 45kg - Màu vàng - Sản phẩm chất lượng của Công ty CP TM GAS BÌNH MINH",
    },
    {
      'name': 'Thiết bị cảnh báo rỏ rỉ gas',
      'image': 'images/recentImages/bao-chay-lon.jpg',
      'oldPrice': 300000,
      'price': 250000,
      'prodDesc':
          "Khi có khí gas rò rỉ vượt mức quy định, thiết bị sẽ phát âm thanh báo động. - Đặc điểm: độ nhạy cao, báo động nhanh, bền. - Bảo hành: 1 năm - Nhân viên Bình Minh sẽ phụ trách lắp đặt và hướng dẫn sử dụng.",
    },
    {
      'name': 'Van điều áp',
      'image': 'images/recentImages/shell-gas-lon.jpg',
      'oldPrice': 300000,
      'price': 220000,
      'prodDesc':
          "Van điều áp sử dụng cho bình gas Shell xanh - Có tính năng ngắt gas tự động (tự động khóa gas khi ống gas bị sứt, đứt hoặc rò rỉ lớn).",
    },
    {
      'name': 'Van điều áp bình đỏ',
      'image': 'images/recentImages/hinh-val-do.jpg',
      'oldPrice': 400000,
      'price': 350000,
      'prodDesc':
          "Van điều áp sử dụng cho bình gas màu đỏ - Có tính năng ngắt gas tự động (tự động khóa gas khi ống gas bị sứt, đứt hoặc rò rỉ lớn).",
    },
    {
      'name': 'Van cao áp (Van khè)',
      'image': 'images/recentImages/van-khe-lon.jpg',
      'oldPrice': 1500000,
      'price': 1350000,
      'prodDesc':
          "Van cao áp (Van khè) - Bảo hành : 1 năm",
    },
  ];
}
