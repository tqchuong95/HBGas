import 'package:gasgasapp/model/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gasgasapp/ui/cart_product_details.dart';
import 'package:gasgasapp/ui/similar_products.dart';

class ProductDetails extends StatefulWidget {
  final productDetailsName;
  final productDetailsImage;
  final productDetailsoldPrice;
  final productDetailsPrice;
  final productDetailsDesc;

  ProductDetails(
      {this.productDetailsName,
      this.productDetailsImage,
      this.productDetailsoldPrice,
      this.productDetailsPrice,
      this.productDetailsDesc});

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  bool liked = false;
  String id;
  final databaseReference = Firestore.instance;
  User _user = User();
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFFB33771),
        title: Text("Hoa Binh Gas"),
        actions: <Widget>[
          Stack(
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => CartProductDetails(
                        cartProductName: widget.productDetailsName,
                        cartProductImage: widget.productDetailsImage,
                        cartProductPrice: widget.productDetailsPrice,
                      ),
                    ),
                  );
                },
              ),
              Positioned(
                  top: 0,
                  right: 0,
                  child: new Stack(
                    children: <Widget>[
                      Icon(Icons.brightness_1,
                          size: 20.0, color: Colors.green[800]),
                      Positioned(
                          top: 4.0,
                          right: 5.0,
                          child: new Center(
                            child: new Text(
                              _currentIndex.toString(),
                              style: new TextStyle(
                                  color: Colors.white,
                                  fontSize: 11.0,
                                  fontWeight: FontWeight.w500),
                            ),
                          )),
                    ],
                  )),
            ],
          )
        ],
      ),
      body: ListView(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 20.0, left: 20.0),
                child: Text(
                  "${widget.productDetailsName}",
                  style: TextStyle(
                      color: Color(0xFFB33771),
                      fontWeight: FontWeight.bold,
                      fontSize: 20.0),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0, left: 20.0),
                child: IconButton(
                  color: liked ? Color(0xFFB33771) : Colors.grey,
                  icon: liked
                      ? Icon(Icons.favorite)
                      : Icon(Icons.favorite_border),
                  onPressed: () async {
                    if (!liked) {
                      String userId = await _user.inputData();
                      DocumentReference ref = await Firestore.instance
                          .collection(userId)
                          .document("data")
                          .collection("favorites")
                          .add({
                        'name': widget.productDetailsName,
                        'image': widget.productDetailsImage,
                        'price': widget.productDetailsPrice,
                      });
                      setState(() {
                        liked = !liked;
                        id = ref.documentID;
                      });
                      print(ref.documentID);
                      Fluttertoast.showToast(
                          msg: "Item Added to Favorites",
                          toastLength: Toast.LENGTH_LONG);
                    }
                  },
                ),
              ),
            ],
          ),
          Container(
            height: 300.0,
            child: Image.asset(
              widget.productDetailsImage,
            ),
          ),

          // ------------------- Price Details ------------------

          Padding(
            padding: const EdgeInsets.only(top: 20.0, left: 20.0),
            child: Row(
              children: <Widget>[
                Text("Giá gốc :  "),
                Text(
                  " ${widget.productDetailsoldPrice} VND",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      decoration: TextDecoration.lineThrough),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20.0, left: 20.0),
            child: Row(
              children: <Widget>[
                Text("Giá khuyến mãi :  "),
                Text(
                  " ${widget.productDetailsPrice} VND",
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20.0, left: 20.0),
            child: Row(
              children: <Widget>[
                Text("Tiết kiệm :  "),
                Text(
                  " ${widget.productDetailsoldPrice - widget.productDetailsPrice} VND",
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          //  ---------------------- Add to Cart Buttons ------------

          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 12.0),
            child: MaterialButton(
              textColor: Colors.white,
              padding: EdgeInsets.all(15.0),
              child: Text("Thêm vào giỏ hàng"),
              onPressed: () async {
                String userId = await _user.inputData();
                DocumentReference ref = await Firestore.instance
                    .collection(userId)
                    .document("data")
                    .collection("cartItems")
                    .add({
                  'name': widget.productDetailsName,
                  'image': widget.productDetailsImage,
                  'price': widget.productDetailsPrice,
                });
                setState(() {
                  id = ref.documentID;
                  _currentIndex = _currentIndex + 1;
                });
                Fluttertoast.showToast(
                  msg: "Product Added to Cart",
                );
              },
              color: Color(0xFFB33771),
            ),
          ),

          // -------- About this Item ------------
          Padding(
            padding: const EdgeInsets.only(left: 5.0, top: 20.0, bottom: 20.0),
            child: ListTile(
              title: Text(
                "Mô tả",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 5.0),
                child: Text("${widget.productDetailsDesc}"),
              ),
            ),
          ),
          Padding(
            child: Text(
              "Sản phẩm tham khảo",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
            ),
            padding: EdgeInsets.only(left: 20.0, bottom: 10.0),
          ),
          Container(
            height: 400.0,
            padding: const EdgeInsets.only(bottom: 20.0),
            child: SimilarProducts(),
          ),
        ],
      ),
    );
  }
}
