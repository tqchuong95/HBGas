import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:gasgasapp/model/user.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gasgasapp/ui/payment_product.dart';

class CartProductDetails extends StatefulWidget {
  final cartProductName;
  final cartProductImage;
  final cartProductPrice;

  CartProductDetails({
    this.cartProductName,
    this.cartProductImage,
    this.cartProductPrice,
  });

  @override
  _CartProductDetailsState createState() => _CartProductDetailsState();
}

class _CartProductDetailsState extends State<CartProductDetails> {
  User _user = User();
  String userID = 'default';
  double totalPrice = 280000;

  @override
  void initState() {
    super.initState();
    initUserID();
  }

  void initUserID() async {
    String uid = await _user.inputData();
    setState(() {
      userID = uid;
    });
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFFB33771),
        title: Text("Giỏ hàng"),
      ),
      body: Container(
        padding: const EdgeInsets.all(8.0),
        child: ListView(
          children: <Widget>[

            Container(
              height: height / 1.4,
              child: StreamBuilder<QuerySnapshot>(
                stream: Firestore.instance
                    .collection(userID)
                    .document("data")
                    .collection('cartItems')
                    .snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.hasData) {
                    return ListView(
                      children: snapshot.data.documents
                          .map((DocumentSnapshot document) {

                        return Card(
                          elevation: 8.0,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ListTile(
                              leading: Image.asset(
                                "${document.data['image']}",
                              ),
                              title: Text("${document.data['name']}"),
                              subtitle: Text("${document.data['price']} VND"),
                              trailing: IconButton(
                                icon: Icon(
                                  Icons.delete_outline,
                                  color: Colors.red,
                                ),
                                onPressed: () async {
                                  setState(() {
                                    Firestore.instance
                                        .collection(userID)
                                        .document("data")
                                        .collection("cartItems")
                                        .document(document.documentID)
                                        .delete();
                                  });
                                  Fluttertoast.showToast(
                                      msg: "Sản phẩm đã được xóa!",
                                      toastLength: Toast.LENGTH_LONG);
                                },
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    );
                  } else {
                    return Container();
                  }
                },
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 20.0, right: 20.0, top: 0.0, bottom: 20.0),
              child:
                  Row(
                  children: <Widget>[
                    Container(
                        width: width/2.3,
                        child: Text("Tổng đơn hàng: ", textAlign: TextAlign.start,),
                    ),
                    Container(
                      width: width/2.5,
                        child: Text('$totalPrice VND',textAlign: TextAlign.end,)
                    )
                  ],
                  ),

            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(
                  left: 20.0, right: 20.0, top: 12.0, bottom: 20.0),
              child: MaterialButton(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0)),
                color: Color(0xFFB33771),
                minWidth: MediaQuery.of(context).size.width,
                textColor: Colors.white,
                padding: EdgeInsets.all(15.0),
                child: Text(
                  "Tiến hành thanh toán",
                  style: _btnStyle(),
                ),
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => ConfirmOrderPage()));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  TextStyle _btnStyle() {
    return TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.bold,
    );
  }
}
